
(function() {
    'use strict';

    angular
        .module('app.main.messenger', [
        ]);
})();
/**
 * Created by DucLT on 11/29/2016 AD.
 */
